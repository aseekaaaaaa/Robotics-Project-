function outputArg1 = normalizeAngle(z)
%NORMALIZE Summary of this function goes here
%   Detailed explanation goes here
    outputArg1 = atan2(sin(z),cos(z));
end

